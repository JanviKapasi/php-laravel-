<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'];
  $lname = $_POST['lname'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $string = "|";
  $string1 ="\n";
  $message = false;
}
function loadData() {
  $file = fopen("data.txt", "a+");
  while($line = fgets($file)) {
      $fields = explode("|", $line);

      if(count($fields) > 1) {
          $name = $fields[0];
          $lname = $fields[1];
          $email = $fields[2];
          $phone = $fields[3];
      }    
  }
}


function checkEmail($currentEmail) {
  $file = fopen("data.txt", "r+");
  while($line = fgets($file)) {
      $fields = explode("|", $line);
      $email = $fields[2];
      if($email == $currentEmail) {
          return false;
      }
  }
  return true;
}
// Check if the form was submitted
function validateData($name, $currentemail, $phone)
{
       //validate the form data
    $errors = [];
    //validate the name and last name field
    if(!preg_match("/^([a-zA-Z' ]+)$/",$name) && !preg_match("/^([a-zA-Z' ]+)$/",$name)){
    $errors[] = 'Invalid name given.';
  }
  // checking email 
  if(!checkEmail(($currentemail)))
        {
           $errors[] = "$currentemail already exists";
        }
        elseif(!filter_var($currentemail, FILTER_VALIDATE_EMAIL))
        {
          $errors[] = "$currentemail is not a valid email address";
        }
        else{

        }
      
   

    // Validate the phone field
$phone1 = preg_replace('/[^0-9]/', '', $phone); // Remove non-digit characters
if (!preg_match('/^[0-9]{10}+$/', $phone1)) 
{
  // Phone number is not 10 digits long
  $errors[] = "Enter valid phone number";
} else {
  // Phone number is valid
  $phone = substr($phone, 0, 3) . '-' . substr($phone, 3, 3) . '-' . substr($phone, 6);
  // Format the phone number as XXX-XXX-XXXX
}
// If there are no validation errors, insert the data into the database
if (empty($errors)) {
  // TODO: Insert the data into the database here
  echo "Data inserted successfully";
} else {
  // If there are validation errors, display them to the user
  echo "Validation errors:<br>";
  foreach ($errors as $error) {
    echo "- $error<br>";
  }
}
}
// Check if the form was submitted
function saveData()
{
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $name = $_POST['name'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $string = "|";
    $string1 ="\n";
    // Validate the form data
    validateData($name, $email, $phone);
    $file=fopen("data.txt","a+");
    fwrite($file,$name);
    fwrite($file,$string);
    fwrite($file,$lname);
    fwrite($file,$string);
    fwrite($file,$email);
    fwrite($file,$string);
    fwrite($file,$phone);
    fwrite($file,$string1);
    }
}

saveData();
  
?>