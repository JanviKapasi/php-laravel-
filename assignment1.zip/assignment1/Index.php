<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$error_file = fopen('error.log', 'a');
$error_message = date('Y-m-d H:i:s') . ' - ' . error_get_last(). PHP_EOL;
fwrite($error_file, $error_message);
fclose($error_file);
//Step-2
include("form.html")

?>